<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>


export default {
  name: 'app',
  components: {
   
  }
}
</script>

<style>
html{
  font-size: 10px;
}
 body{
   margin: 0;
 }
 .el-card{
    padding: 0rem;
  }
</style>


